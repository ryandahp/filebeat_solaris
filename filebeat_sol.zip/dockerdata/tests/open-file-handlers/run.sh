/etc/init.d/metricbeat start
cd /filebeat
./filebeat -httpprof :6060
